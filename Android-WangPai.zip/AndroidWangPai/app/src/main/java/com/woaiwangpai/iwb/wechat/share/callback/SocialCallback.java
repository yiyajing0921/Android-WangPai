package com.woaiwangpai.iwb.wechat.share.callback;

/**
 * Created by arvinljw on 17/11/24 16:21
 * Function：
 * Desc：
 */
public interface SocialCallback {
    void socialError(String msg);
}
