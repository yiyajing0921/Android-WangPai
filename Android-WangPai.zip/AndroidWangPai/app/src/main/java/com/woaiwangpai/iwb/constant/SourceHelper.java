package com.woaiwangpai.iwb.constant;

/**
 * @Author : YiYaJing
 * @Data : 2019/10/21 17:35
 * @Class : 字段记录
 */
public class SourceHelper {
    //会员TabLayout
    public static final String supermember = "超级会员";
    public static final String member = "会员";
    public static final String nonMember = "非会员";


}
