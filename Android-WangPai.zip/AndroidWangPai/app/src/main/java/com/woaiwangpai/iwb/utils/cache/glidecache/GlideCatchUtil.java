package com.woaiwangpai.iwb.utils.cache.glidecache;

import android.os.Looper;

import com.bumptech.glide.Glide;
import com.woaiwangpai.iwb.MyApplication;
import com.woaiwangpai.iwb.utils.LogUtils;
import com.woaiwangpai.iwb.utils.cache.glidecache.config.GlideCatchConfig;

import java.io.File;
import java.math.BigDecimal;


/**
 * @Author : YiYaJing
 * @Data : 2020/6/17 9:01
 * @Email : yiyajing8023@163.com
 * @Description : Glide缓存工具类
 */
@SuppressWarnings("ResultOfMethodCallIgnored")
public class GlideCatchUtil {
    private static GlideCatchUtil instance;

    public static GlideCatchUtil getInstance() {
        if (null == instance) {
            instance = new GlideCatchUtil();
        }
        return instance;
    }
//"Glide磁盘缓存大小:" + GlideCatchUtil.getInstance().getCacheSize()
    // 获取Glide磁盘缓存大小
    public String getCacheSize() {
        try {
           LogUtils.e("path"+ MyApplication.getInstance().getPackageName(), MyApplication.getInstance().getCacheDir()+"");
            return getFormatSize(getFolderSize(new File(MyApplication.getInstance().getCacheDir() + "/" + GlideCatchConfig.GLIDE_CARCH_DIR)));

        } catch (Exception e) {
            e.printStackTrace();
            return "获取失败";
        }
    }
//GlideCatchUtil.getInstance().cleanCatchDisk())
//showToast("清除Glide磁盘缓存成功，删除文件夹方法");
    // 清除Glide磁盘缓存，自己获取缓存文件夹并删除方法

    public boolean cleanCatchDisk() {
        return deleteFolderFile(MyApplication.getInstance().getCacheDir() + "/" + GlideCatchConfig.GLIDE_CARCH_DIR, true);
    }

//(GlideCatchUtil.getInstance().clearCacheDiskSelf()) {
//showToast("清除Glide磁盘缓存成功，Glide自带方法");
    // 清除图片磁盘缓存，调用Glide自带方法
    public boolean clearCacheDiskSelf() {
        try {
            if (Looper.myLooper() == Looper.getMainLooper()) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Glide.get(MyApplication.getInstance()).clearDiskCache();
                    }
                }).start();
            } else {
                Glide.get(MyApplication.getInstance()).clearDiskCache();
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
//(GlideCatchUtil.getInstance().clearCacheMemory()) {
//                    showToast("清除Glide内存缓存成功");
    // 清除Glide内存缓存

    public boolean clearCacheMemory() {
        try {
            if (Looper.myLooper() == Looper.getMainLooper()) { //只能在主线程执行
                Glide.get(MyApplication.getInstance()).clearMemory();
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }


    // 获取指定文件夹内所有文件大小的和
    private long getFolderSize(File file) throws Exception {
        long size = 0;
        try {
            File[] fileList = file.listFiles();
            for (File aFileList : fileList) {
                if (aFileList.isDirectory()) {
                    size = size + getFolderSize(aFileList);
                } else {
                    size = size + aFileList.length();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return size;
    }

    // 格式化单位
    private static String getFormatSize(double size) {
        double kiloByte = size / 1024;
        if (kiloByte < 1) {
            return size + "Byte";
        }
        double megaByte = kiloByte / 1024;
        if (megaByte < 1) {
            BigDecimal result1 = new BigDecimal(Double.toString(kiloByte));
            return result1.setScale(2, BigDecimal.ROUND_HALF_UP).toPlainString() + "KB";
        }
        double gigaByte = megaByte / 1024;
        if (gigaByte < 1) {
            BigDecimal result2 = new BigDecimal(Double.toString(megaByte));
            return result2.setScale(2, BigDecimal.ROUND_HALF_UP).toPlainString() + "MB";
        }
        double teraBytes = gigaByte / 1024;
        if (teraBytes < 1) {
            BigDecimal result3 = new BigDecimal(Double.toString(gigaByte));
            return result3.setScale(2, BigDecimal.ROUND_HALF_UP).toPlainString() + "GB";
        }
        BigDecimal result4 = new BigDecimal(teraBytes);
        return result4.setScale(2, BigDecimal.ROUND_HALF_UP).toPlainString() + "TB";
    }

    // 按目录删除文件夹文件方法
    private boolean deleteFolderFile(String filePath, boolean deleteThisPath) {
        try {
            File file = new File(filePath);
            if (file.isDirectory()) {
                File files[] = file.listFiles();
                for (File file1 : files) {
                    deleteFolderFile(file1.getAbsolutePath(), true);
                }
            }
            if (deleteThisPath) {
                if (!file.isDirectory()) {
                    file.delete();
                } else {
                    if (file.listFiles().length == 0) {
                        file.delete();
                    }
                }
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

}
