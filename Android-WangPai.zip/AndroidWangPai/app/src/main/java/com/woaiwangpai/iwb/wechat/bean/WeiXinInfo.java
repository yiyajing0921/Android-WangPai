package com.woaiwangpai.iwb.wechat.bean;

/**
 * @author
 * @create time 2017-09-14
 */
public class WeiXinInfo {
    private String openid;//
    private String headimgurl;//用户头像URL
    private String nickname="";
    private int age;

    public String getHeadimgurl() {
        return headimgurl;
    }

    public void setHeadimgurl(String headimgurl) {
        this.headimgurl = headimgurl;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }
}
