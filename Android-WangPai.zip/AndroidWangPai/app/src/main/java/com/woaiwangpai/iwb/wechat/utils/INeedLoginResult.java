package com.woaiwangpai.iwb.wechat.utils;

/**
 * Created by arvinljw on 2018/9/27 15:26
 * Function：
 * Desc：
 */
public interface INeedLoginResult {
    void setNeedLoginResult(boolean needLoginResult);

    boolean isNeedLoginResult();
}
