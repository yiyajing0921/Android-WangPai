package com.woaiwangpai.iwb.mvp.interfaces;

/**
 * Created by Gabriel on 2018/10/19.
 * Email 17600284843@163.com
 */

public interface IModel {
    void onDestroy();
}
