package com.woaiwangpai.iwb.mvp.network.callback.loadsir;

import com.kingja.loadsir.callback.Callback;
import com.woaiwangpai.iwb.R;

/**
 * @author Qin
 * @data 2018/4/12
 * Content
 */

public class FinancialCallback extends Callback {
    @Override
    protected int onCreateView() {
        return R.layout.layout_financial_callback;
    }
}
