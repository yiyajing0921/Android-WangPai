package com.tencent.qcloud.tim.uikit.modules.contact.interfaces;

import com.tencent.qcloud.tim.uikit.base.ILayout;
import com.tencent.qcloud.tim.uikit.modules.contact.ContactListView;

public interface IContactLayout extends ILayout {

    ContactListView getContactListView();

}
