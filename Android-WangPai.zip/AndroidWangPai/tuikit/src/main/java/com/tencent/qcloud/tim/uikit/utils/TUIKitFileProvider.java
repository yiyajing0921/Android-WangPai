package com.tencent.qcloud.tim.uikit.utils;


import androidx.core.content.FileProvider;

public class TUIKitFileProvider extends FileProvider {
}
