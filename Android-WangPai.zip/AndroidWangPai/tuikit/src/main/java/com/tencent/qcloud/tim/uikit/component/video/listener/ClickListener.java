package com.tencent.qcloud.tim.uikit.component.video.listener;


public interface ClickListener {
    void onClick();
}
