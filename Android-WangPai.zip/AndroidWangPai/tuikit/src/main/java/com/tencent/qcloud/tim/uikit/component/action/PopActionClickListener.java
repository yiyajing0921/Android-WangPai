package com.tencent.qcloud.tim.uikit.component.action;


public interface PopActionClickListener {
    void onActionClick(int position, Object data);
}
