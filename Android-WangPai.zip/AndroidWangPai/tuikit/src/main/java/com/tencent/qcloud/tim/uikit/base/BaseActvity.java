package com.tencent.qcloud.tim.uikit.base;

import android.app.Activity;


public class BaseActvity extends Activity {
}
