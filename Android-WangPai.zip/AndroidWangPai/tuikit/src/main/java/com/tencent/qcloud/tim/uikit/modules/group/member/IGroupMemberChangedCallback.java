package com.tencent.qcloud.tim.uikit.modules.group.member;

public interface IGroupMemberChangedCallback {
    void onMemberRemoved(GroupMemberInfo memberInfo);
}
